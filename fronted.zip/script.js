// Начальные данные (имитация базы данных)
let products = [
    { id: 1, name: "80 Гемов", game: "Brawl Stars", price: 120 },
    { id: 2, name: "Лицензия Java", game: "Minecraft", price: 1900 },
    { id: 3, name: "Нож 'M9 Bayonet'", game: "Standoff 2", price: 4500 }
];

const grid = document.getElementById('productsGrid');

// Функция для отрисовки всех товаров
function renderProducts() {
    grid.innerHTML = ''; // Очищаем сетку
    products.forEach(item => {
        grid.innerHTML += `
            <div class="product-card">
                <div style="height:120px; background:#333; border-radius:10px; margin-bottom:10px"></div>
                <h3>${item.name}</h3>
                <p style="color:#888">${item.game}</p>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:15px">
                    <span class="product-price">${item.price} ₽</span>
                    <button onclick="buyItem(${item.id})" style="background:#00d1ff; border:none; border-radius:5px; padding:5px 10px; cursor:pointer">Купить</button>
                </div>
            </div>
        `;
    });
}

// Добавление нового товара
function addNewProduct() {
    const name = document.getElementById('pName').value;
    const price = document.getElementById('pPrice').value;

    if(name && price) {
        products.unshift({ id: Date.now(), name: name, game: "Новинка", price: price });
        renderProducts();
        closeModal();
    }
}

// Функции модального окна
function openModal() { document.getElementById('modal').style.display = 'flex'; }
function closeModal() { document.getElementById('modal').style.display = 'none'; }

function buyItem(id) {
    alert("Товар добавлен в корзину! ID: " + id);
    let count = document.getElementById('cartCount');
    count.innerText = parseInt(count.innerText) + 1;
}

// Запуск при загрузке
renderProducts();
